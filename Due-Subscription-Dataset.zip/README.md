# Due subscription information extraction

Created by Dol Raj Bashyal for a natural-language subscription-entry model.

## Data source

The 3,796 training descriptions are synthetic. They were generated from 58 subscription patterns and 20 unrelated-text patterns using seed 32602, then deduplicated and shuffled. Development (62 descriptions) and final evaluation (84 descriptions) were authored separately. Prices and subscriptions are hypothetical examples; no customer data was collected.

## Raw data

`raw/subscription_descriptions.csv` contains all 3,942 descriptions. Columns:

- `id`: stable example identifier.
- `split`: train, development, or final.
- `text`: subscription or unrelated description.
- `annotated_text`: the description with `[[FIELD|value]]` annotation tags.
- `origin`: synthetic-v2, synthetic-negative-v2, or authored-holdout-v2.
- `template_family`: generation pattern or holdout group.

`raw/sentence_patterns.json` contains the original patterns and generation values. Raw training markup was recovered by rerunning the original generator with its original seed, and checked against the saved experiment. Development and final `.annotated.txt` files are the original authored sources. JSONL versions preserve descriptions that contain newlines.

## Processed data

Each file in `processed/` contains JSONL records with `text`, `entities`, `origin`, and `family`. Each entity has `label`, `text`, `start`, and `end`. Offsets are zero-based Python character offsets; `end` is exclusive. An unrelated description has an empty entity list.

The eight fields are service, amount, currency, cycle, billing date, trial end, reminder, and plan type. BIO token labels are created during preprocessing in the notebook. The saved processed splits match the original experiment byte for byte.

## Reference experiment

`reference/` contains the existing experiment's model comparisons, predictions, and training history. The original v2 model achieved 97.34% entity F1 and 85.71% complete-entry accuracy (72/84 final descriptions). These reports are not used as training features or labels. The final set is an already evaluated benchmark, not a new untouched test set.

`tokenizer/` contains the cased WordPiece tokenizer used by the original model. Model weights are not included.
